"""Independent arithmetic review of raw replay metrics; no simulation internals imported."""
import json, sys
rows=[json.loads(line) for line in open(sys.argv[1])]
choices=('W','E','Decline')
EPS=(0,0,1000000,1000000,1000000,1000000)
def vector(o,union=False):
 m=o['metrics']
 return (m['attainment_month'] or 25,m['guardrail_union_months'] if union else sum(m['guardrail_months']),-m['treasury_less_unpaid_future_e'],*[-n for n in m['final_three_recurring']])
def relation(a,b,eps):
 return [0 if abs(x-y)<=e else (-1 if x<y else 1) for x,y,e in zip(a,b,eps)]
def dominates(a,b,eps):
 r=relation(a,b,eps);return max(r)<=0 and min(r)<0
summary={'source':'Independent Python arithmetic over disclosed raw outcomes, not another game replay','b15':[],'b1':[]}
for row in rows:
 if row['kind']!='bounded_b15':continue
 assert row['scripts']==111 and all(c['fatal']==0 for c in row['counts'].values())
 for union,key in [(False,'sum'),(True,'union')]:
  groups={c:[o for o in row['outcomes'] if o['choice']==c] for c in choices}
  assert all(len(g)==37 for g in groups.values())
  fronts={c:[o for o in g if not any(dominates(vector(x,union),vector(o,union),(0,)*6) for x in g)] for c,g in groups.items()}
  witnesses=[];strong=[]
  for candidate in row['outcomes']:
   a=vector(candidate,union); others=[g for c,g in groups.items() if c!=candidate['choice']]
   if all(all(max(relation(a,vector(x,union),EPS))<=0 for x in g) and any(min(relation(a,vector(x,union),EPS))<0 for x in g) for g in others): witnesses.append(candidate['id'])
   if all(all(dominates(a,vector(x,union),EPS) for x in g) for g in others):strong.append(candidate['id'])
  def covers(a,b):return all(any(all(v==0 for v in relation(vector(x,union),vector(y,union),EPS)) for y in b) for x in a)
  equal=all(covers(fronts[a],fronts[b]) and covers(fronts[b],fronts[a]) for i,a in enumerate(choices) for b in choices[i+1:])
  expected=row[key]
  assert set(witnesses)=={x['script_id'] for x in expected['witnesses']}
  assert equal==expected['all_equivalent']
  assert (not witnesses and not equal)==expected['pass']
  for f in expected['frontiers']:assert {x['id'] for x in fronts[f['choice']]}==set(f['script_ids'])
  summary['b15'].append({'site':row['site'],'route':row['route'],'aggregation':key,'pass':expected['pass'],'witnesses':witnesses,'strict_against_every_other_script_witnesses':strong,'all_equivalent':equal})
b1=next(r for r in rows if r['kind']=='bounded_b1')
for pair in b1['results']:
 if pair['choice']!='Decline':continue
 selected=[]
 for route,key in [(1,'fastest_then_cheapest'),(2,'cheapest_then_fastest')]:
  outcomes=next(r for r in rows if r['kind']=='bounded_b15' and r['site']==pair['site'] and r['route']==route)['government_capital_outcomes']
  outcomes=[x for x in outcomes if x['choice']=='Decline']
  ordering=(lambda x:(x['attainment_month'],x['capital']['total']['net_committed'])) if route==1 else (lambda x:(x['capital']['total']['net_committed'],x['attainment_month']))
  best=min(map(ordering,outcomes)); winners=[x for x in outcomes if ordering(x)==best]
  assert {x['script_id'] for x in winners}=={x['script_id'] for x in pair['route'+str(route)][key]}
  points=sorted(set((x['attainment_month'],x['capital']['total']['net_committed']) for x in outcomes))
  frontier=[p for p in points if not any(q!=p and all(a<=b for a,b in zip(q,p)) for q in points)]
  assert set(frontier)=={(x['attainment_month'],x['capital']['total']['net_committed']) for x in pair['route'+str(route)]['exact_pareto_frontier']}
  selected.append(winners[0]);summary['b1'].append({'site':pair['site'],'route':route,'script':winners[0]['script_id'],'month':winners[0]['attainment_month'],'capital':winners[0]['capital']['total'],'frontier_points':frontier})
 a,b=selected
 assert pair['fastest_vs_cheapest_pass']==(b['attainment_month']-a['attainment_month']>=2 and b['capital']['total']['net_committed']<a['capital']['total']['net_committed'])
print(json.dumps(summary,ensure_ascii=False,indent=2))
