import datetime
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root = Path.cwd()
out = root / 'target/d031'
binary = root / 'target/release/examples/governance_replay'
argv = [str(binary), '--include-delayed-policy', '--require-acceptance']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out / '444-raw.jsonl').open('wb') as stdout, (out / '444.stderr').open('wb') as stderr:
    result = subprocess.run(argv, stdout=stdout, stderr=stderr)
(out / 'exit-code.txt').write_text(str(result.returncode) + '\n')
summary = {}
new_script_hashes = []
execution_errors = []

def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()

with (out / '444-raw.jsonl').open() as raw, (out / '444-compact.jsonl').open('w') as compact:
    for line in raw:
        row = json.loads(line)
        kind = row['kind']
        if kind == 'script_replay':
            replay = row['replay']
            new_script_hashes.append((replay['script'], canonical(replay)))
            if replay['execution_error']:
                execution_errors.append(replay['execution_error'])
        else:
            compact.write(line)
            if kind == 'script_execution_error' or kind == 'driver_error':
                execution_errors.append(row)
            if kind == 'bounded_b15':
                summary.setdefault('b15', []).append({k:row[k] for k in ['site','route','raw_pass','policy_pass','exception_reason','sum','union','aggregation_sensitive','counts'] if k in row})
            elif kind in ['bounded_b1','bounded_b8','acceptance_result','search_domain']:
                summary[kind] = row
archive = root / 'docs/gameplay/acceptance/2026-10-24/demand-trial/replay-evidence.tar.gz'
old_script_hashes = []
with tarfile.open(archive) as tar:
    old_raw = tar.extractfile('replay/replay/cap-200-444.jsonl')
    for line in old_raw:
        row = json.loads(line)
        if row['kind'] == 'script_replay':
            replay = row['replay']
            old_script_hashes.append((replay['script'], canonical(replay)))
comparison = {'baseline_archive':str(archive),'baseline_member':'replay/replay/cap-200-444.jsonl','baseline_script_count':len(old_script_hashes),'new_script_count':len(new_script_hashes),'all_script_replays_identical':new_script_hashes == old_script_hashes,'comparison_scope':'Every entire script_replay object, including every monthly state and system receipt, report, outcome/metrics, capital, trade, labor audit, failed actions and final scorecards','new_execution_errors':execution_errors,'script_hashes':[{'script':script,'sha256':digest} for script,digest in new_script_hashes]}
(out / 'raw-behavior-comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n')
(out / 'acceptance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

metadata={'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary':str(binary),'binary_sha256':sha(binary),'command_argv':argv,'exit_code':result.returncode,'raw_complete_monthly_trace':True,'compact_method':'Filter non-script_replay lines from this same full raw run, without simulation rerun','acceptance_field_semantics':'D031 policy_pass and top-level pass/status use the new bounded decision. raw_pass and all_b15_raw_pass retain the original comparison conclusions. Every sum/union pass, vector, frontier and witness is unchanged. B8 is out_of_scope with no pass. Passing this bounded scope is not experience acceptance.','D031_configuration_scope':'None domestic capacity override resolves D022 200; both trials disabled; no calibration overrides; original 432+12 scripts','design_sha256':{str(p):sha(p) for p in [Path('/Users/wangyucheng/Projects/jinglun-design/design/DECISIONS.md'),Path('/Users/wangyucheng/Projects/jinglun-design/design/handoffs/2026-10-23-first-governance-slice.md')]},'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file() and p.name!='run-metadata.json'}}
(out / 'run-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit_code':result.returncode,'script_count':len(new_script_hashes),'execution_errors':len(execution_errors),'all_script_replays_identical_to_old_200':comparison['all_script_replays_identical'],'acceptance':summary.get('acceptance_result')},ensure_ascii=False))
assert len(new_script_hashes)==444
assert new_script_hashes==old_script_hashes
assert not execution_errors
