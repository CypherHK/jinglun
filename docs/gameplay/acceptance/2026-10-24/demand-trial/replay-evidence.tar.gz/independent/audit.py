import argparse, collections, hashlib, json, math, pathlib, subprocess
from decimal import Decimal as D

p=argparse.ArgumentParser();p.add_argument('--log',type=pathlib.Path);p.add_argument('--allow-partial',action='store_true');p.add_argument('--replay',action='append',default=[]);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args()
docpath=pathlib.Path('crates/gameplay/data/jinglun-040-initial-draft.json')
d=json.loads(docpath.read_text(),parse_float=D);params=d['parameters'];v=lambda x:D(str(x['value']))
val=lambda k:v(params[k]);money_scale=100_000_000
subsidies={str(site):{g:max(D(0),v(d['candidate_capital'][str(site)]['factory_capital'])+val('operating_cash_buffer')-val('group_'+g.lower()+'_starting_cash')) for g in ['A','B']} for site in [8,29]}
allocations=[{'group_at_8':g,'group_at_29':h,'subsidy_at_8':subsidies['8'][g],'subsidy_at_29':subsidies['29'][h],'total_subsidy':subsidies['8'][g]+subsidies['29'][h],'treasury_shortfall':subsidies['8'][g]+subsidies['29'][h]-val('opening_treasury')} for g,h in [('A','B'),('B','A')]]
full={}
for name in ['ordinary','maritime','long']:
 revenue=val('new_factory_output')*val('goods_price');wages=val('new_factory_workers')*val('monthly_wage');energy=val('new_factory_energy')*val(name+'_energy_price');fixed=val('factory_other_fixed_monthly_cost');tax=revenue*val('manufacturing_sales_tax_rate');profit=revenue-wages-energy-fixed-tax
 full[name]={'gross_revenue':revenue,'wages':wages,'energy':energy,'fixed':fixed,'sales_tax':tax,'after_tax_profit':profit,'profit_over_gross_revenue':profit/revenue,'within_15_to_25_percent':D('.15')<=profit/revenue<=D('.25')}
base_tax=v(d['fiscal']['existing_tax_revenue']);spend=v(d['fiscal']['recurring_spending']);aid=val('monthly_transition_aid');gap=spend-base_tax
# Compare numeric identity recursively, retaining type as well as value.
old=json.loads(subprocess.check_output(['git','show','3f8bfb423d6d686da03c25b7fcab706e3ddd6af9:crates/gameplay/data/jinglun-040-initial-draft.json']))
new=json.loads(docpath.read_text())
def nums(x,path=''):
 if isinstance(x,bool):return {}
 if isinstance(x,(float,int)):return {path:(type(x).__name__,x)}
 if isinstance(x,dict):return {k2:v2 for k,v in x.items() for k2,v2 in nums(v,path+'/'+k).items()}
 if isinstance(x,list):return {k2:v2 for i,v in enumerate(x) for k2,v2 in nums(v,path+'/'+str(i)).items()}
 return {}
n1,n2=nums(old),nums(new);diff=[k for k in n1.keys()|n2.keys() if n1.get(k)!=n2.get(k)]
static={'confirmed_numeric_path_count':len(n1),'numeric_type_value_differences':diff,'document_sha256':hashlib.sha256(docpath.read_bytes()).hexdigest(),'aid':aid,'existing_tax_income':base_tax,'spending':spend,'post_aid_gap':gap,'aid_over_gap':aid/gap,'aid_period_net_recurring':base_tax+aid-spend,'gap_over_spending':gap/spend,'gap_in_full_output_factory_tax_units':gap/v(d['fiscal']['reference_factory_tax']),'opening_treasury':val('opening_treasury'),'first_factory_minimum_subsidies':subsidies,'distinct_group_allocations':allocations,'remaining_after_subsidy':{str(site):{g:val('opening_treasury')-subsidies[str(site)][g] for g in ['A','B']} for site in [8,29]},'frozen_illustrative_early_work_cost_by_candidate':{str(site):v(d['capital_feasibility']['early_works_packages'][str(site)]['natural_adjusted_cost']) for site in [8,29]},'early_public_work_reserve':val('early_public_works_reserve'),'remaining_after_subsidy_and_early_reserve':{str(site):{g:val('opening_treasury')-subsidies[str(site)][g]-val('early_public_works_reserve') for g in ['A','B']} for site in [8,29]},'nominal_full_output_margins':full,'cap_scope':'Cap replaces only new-factory domestic import-substitution capacity, not protected existing 425 monthly output/sales or D022 JSON numeric values.'}
result={'static_d020':static,'domain_note':'Bounded public-command scripts; diagnostics executing successfully do not assert B8 acceptance. labor_trial=false throughout.'}
if a.log:
 records=collections.defaultdict(list)
 for line in a.log.read_text().splitlines():
  for prefix in ['DEMAND_B8','DEMAND_RETROFIT','DEMAND_D020_NO_ACTION']:
   if line.startswith(prefix+' '):records[prefix].append(json.loads(line[len(prefix)+1:]));break
 if not a.allow_partial:
  assert len(records['DEMAND_B8'])==144, len(records['DEMAND_B8'])
  assert len(records['DEMAND_RETROFIT'])==36, len(records['DEMAND_RETROFIT'])
  assert len(records['DEMAND_D020_NO_ACTION'])==3, len(records['DEMAND_D020_NO_ACTION'])
 b8=[]
 for run in records['DEMAND_B8']:
  rows=run['rows'];site=run['site'];warnings=[]
  for row in rows:
   for f in row['factories']:
    if f['site']==site and f['phase']=='ClosureWarned':
     prev=[(r['month'],p['exports']) for r in rows if r['month']<row['month'] for p in r['factories'] if p['id']==f['id'] and p['exports']>0]
     closed=next((r['month'] for r in rows for p in r['factories'] if p['id']==f['id'] and p['phase']=='Closed'),None)
     alive=next((r['month'] for r in rows if r['month']>row['month'] for p in (r['recovery'] or []) if p['id']==f['id'] and p['phase']=='Operating' and p['profit']>=0 and p['exports']>0),None)
     warnings.append({'factory':f['id'],'warning_month':row['month'],'prior_export_months':prev,'untreated_closure_month':closed,'recovery_profitable_operating_export_month':alive,'recovery_at_untreated_closure':next((p for r in rows if r['month']==closed for p in (r['recovery'] or []) if p['id']==f['id']),None),'slice_rescue':run['recovery_policy']=='warning_month_resign' and bool(prev) and row['month']<=24 and closed is not None and closed<=24 and alive is not None and alive<=24})
  re_sign=next((r['month'] for r in rows if r['resigned']),None)
  first_exports=next((r['month'] for r in rows if r['recovery'] and r['resigned'] and sum(f['exports'] for f in r['recovery'])>0),None)
  b8.append({k:run[k] for k in ['cap','site','prepare','cut','recovery_policy']}|{'first_warning_month':run['warning'],'resign_month':re_sign,'recovery_first_export_month':first_exports,'warnings':warnings,'slice_rescue':any(w['slice_rescue'] for w in warnings)})
 result['b8_scenarios']=b8
 result['b8_counts']=[{'cap':cap,'policy':policy,'runs':len(sub:=[r for r in b8 if r['cap']==cap and r['recovery_policy']==policy]),'warnings_by_m24':sum(r['first_warning_month'] is not None and r['first_warning_month']<=24 for r in sub),'warnings_by_m24_with_prior_exports':sum(any(w['warning_month']<=24 and w['prior_export_months'] for w in r['warnings']) for r in sub),'early_resign_prevents_closure_with_prior_exports':sum(r['recovery_policy']=='early_resign_original' and any(w['warning_month']<=24 and w['prior_export_months'] and r['resign_month'] is not None and r['resign_month']<w['warning_month'] and w['recovery_at_untreated_closure'] is not None and w['recovery_at_untreated_closure']['phase']=='Operating' and w['recovery_at_untreated_closure']['profit']>=0 for w in r['warnings']) for r in sub),'warnings_after_m24':sum(r['first_warning_month'] is not None and r['first_warning_month']>24 for r in sub),'slice_rescues':sum(r['slice_rescue'] for r in sub)} for cap in [100,150,200] for policy in ['early_resign_original','warning_month_resign']]
 result['retrofit_m24']=[r for r in records['DEMAND_RETROFIT'] if r['month']==24]
 noaction=[]
 for run in records['DEMAND_D020_NO_ACTION']:
  rows=[]
  for row in run['rows']:
   m=row['month'];applied=row['applied'];existing=[(k,c['command']['Transfer']['amount']) for k,c in applied.items() if k.startswith('existing/sales/') and k.endswith('/'+str(m)) and 'Transfer' in c['command']]
   rows.append({'month':m,'aid':row['record']['aid']/money_scale,'tax_income':row['actual_tax_income']/money_scale,'spending':row['recurring_spend']/money_scale,'net_recurring':row['record']['recurring_balance']/money_scale,'treasury':row['record']['treasury']/money_scale,'new_factory_output':sum(f['output'] for f in row['factories']),'factories':[{k:f[k] for k in ['id','site','phase','output','after_tax_profit']} for f in row['factories']],'existing_sales_transfers':existing,'existing_sales_currency':sum(x[1] for x in existing)/money_scale})
  noaction.append({'cap':run['cap'],'rows':rows})
 result['no_action_runtime']=noaction
 result['observed_no_action_post_aid_gap_over_spending']=(-noaction[0]['rows'][12]['net_recurring']/noaction[0]['rows'][12]['spending']) if len(noaction)==3 else None
 result['no_action_rows_equal_across_caps']=all(r['rows']==noaction[0]['rows'] for r in noaction) if len(noaction)==3 else None
 result['d020_runtime_fiscal_note']='All three caps give M1-11 zero balance, M12 +1.22 after the autonomous capital plant, M13-24 -0.366. The structural 20.2653 percent gap excludes that new plant; observed post-aid gap is 4.6766 percent of unchanged spending. This pre-existing departure is also present at cap200.'
for entry in a.replay:
 cap,path=entry.split(':',1);data=[];line_count=0
 for line in pathlib.Path(path).open():
  line_count+=1;event=json.loads(line)
  if event.get('kind')=='bounded_b15':data.extend(event['government_capital_records'])
 assert len(data)==444, (path,len(data))
 result.setdefault('replay_files',[]).append({'cap':int(cap),'path':path,'lines':line_count,'script_records':len(data)})
 margins=[];undefined=collections.Counter();errors=sum(row.get('execution_error') is not None for row in data)
 assert errors==0, errors
 for row in data:
  audit=row.get('trade_audit',{})
  for fid,f in audit.get('factories',{}).items():
   for m,rec in f.get('monthly_factory_audit',{}).items():
    if rec.get('actual_revenue',0)==0:
     undefined[rec.get('phase','unknown')]+=1
    if rec.get('engine_costs_apply_this_month'):
     expected=rec['actual_revenue']-sum(rec['engine_accrued_costs'].values())
     assert expected==rec['engine_after_tax_profit_this_month'], (cap,row['script_id'],fid,m,expected,rec)
    if rec.get('actual_revenue',0)>0:
     calculated=rec['engine_after_tax_profit_this_month']/rec['actual_revenue']
     assert abs(calculated-rec['engine_profit_over_actual_revenue'])<1e-12
     energy_mode='long' if rec['energy_long_active'] else ('maritime_only' if rec['ordinary_energy_used']==0 else ('ordinary_only' if rec['maritime_energy_used']==0 else 'mixed_ordinary_maritime'))
     margins.append({'script':row.get('script_id',row.get('script',{})),'factory':fid,'site':f.get('site'),'group':f.get('group'),'month':m,'phase':rec.get('phase'),'output':rec.get('output'),'profit':rec.get('engine_after_tax_profit_this_month'),'revenue':rec['actual_revenue'],'ordinary_energy_used':rec['ordinary_energy_used'],'maritime_energy_used':rec['maritime_energy_used'],'energy_mode':energy_mode,'margin':calculated})
 sorted_margins=sorted(r['margin'] for r in margins)
 def margin_subset(rows):
  return {'count':len(rows),'range':[min((r['margin'] for r in rows),default=None),max((r['margin'] for r in rows),default=None)]}
 result.setdefault('actual_margins',{})[cap]={'zero_revenue_factory_months_by_phase':dict(undefined),'positive_revenue_factory_months':len(margins),'all_active_profit_equals_revenue_minus_accrued_costs':True,'by_energy_mode':{mode:margin_subset([r for r in margins if r['energy_mode']==mode]) for mode in ['ordinary_only','maritime_only','mixed_ordinary_maritime','long']},'by_phase':dict(collections.Counter(r['phase'] for r in margins)),'full_output_100':margin_subset([r for r in margins if r['output']==100]),'reduced_output_under_100':margin_subset([r for r in margins if r['output']<100]),'quartiles_nearest_rank':[sorted_margins[min(len(sorted_margins)-1,math.ceil(q*len(sorted_margins))-1)] if sorted_margins else None for q in [.25,.5,.75]],'range':[min((r['margin'] for r in margins),default=None),max((r['margin'] for r in margins),default=None)],'negative_profit_count':sum(r['profit']<0 for r in margins),'below_15pct_count':sum(r['margin']<.15-1e-9 for r in margins),'within_15_to_25pct_count':sum(.15-1e-9<=r['margin']<=.25+1e-9 for r in margins),'above_25pct_count':sum(r['margin']>.25+1e-9 for r in margins),'minimum_witness':min(margins,key=lambda r:r['margin'],default=None),'maximum_witness':max(margins,key=lambda r:r['margin'],default=None)}
def default(x):
 if isinstance(x,D):return float(x)
 raise TypeError(type(x).__name__)
a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2,default=default)+'\n')
print(json.dumps({'output':str(a.out),'numeric_differences':diff,'b8_counts':result.get('b8_counts'),'actual_margins':result.get('actual_margins')},ensure_ascii=False,default=default))
