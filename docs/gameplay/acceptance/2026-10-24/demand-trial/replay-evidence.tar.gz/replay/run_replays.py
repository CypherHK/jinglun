import concurrent.futures, datetime, hashlib, json, os, platform, subprocess
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'target/demand-trial/replay'; OUT.mkdir(parents=True,exist_ok=True)
BINARY=ROOT/'target/release/examples/governance_replay'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
metadata={'started_at':stamp(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],text=True),'binary':str(BINARY),'binary_sha256':sha(BINARY),'machine':{'platform':platform.platform(),'uname':list(platform.uname()),'cpu_count':os.cpu_count()},'design_hashes':{p.name:sha(p) for p in [Path('/Users/wangyucheng/Projects/jinglun-design/design/DECISIONS.md'),Path('/Users/wangyucheng/Projects/jinglun-design/design/handoffs/2026-10-23-first-governance-slice.md')]},'single_variable':'domestic capacity only; labor recruitment false; 200 is default with no override','runs':{}}
(OUT/'run-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(cap):
 command=[str(BINARY),'--include-delayed-policy','--require-acceptance']
 if cap!=200:command+=['--domestic-capacity-experiment',str(cap)]
 start=stamp();raw=OUT/f'cap-{cap}-444.jsonl';err=OUT/f'cap-{cap}-444.stderr'
 with raw.open('wb') as stdout,err.open('wb') as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr)
 (OUT/f'cap-{cap}-exit-code.txt').write_text(str(p.returncode)+'\n')
 count=0;errors=0;size=0;domain=None
 with raw.open() as src,(OUT/f'cap-{cap}-compact.jsonl').open('w') as dst:
  for line in src:
   row=json.loads(line)
   if row['kind']=='script_replay':
    count+=1;errors+=row['replay']['execution_error'] is not None
   else:
    dst.write(line);size+=len(line.encode())
   if row['kind']=='search_domain':domain=row
 assert count==444,(cap,count);assert domain['labor_recruitment_experiment'] is False
 assert domain['domestic_demand_trial_cap']==(None if cap==200 else cap)
 return str(cap),{'command':command,'started_at':start,'finished_at':stamp(),'exit_code':p.returncode,'scripts':count,'execution_errors':errors,'raw_sha256':sha(raw),'raw_bytes':raw.stat().st_size,'compact_bytes':size,'stderr_bytes':err.stat().st_size,'binary_sha256_after':sha(BINARY)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for cap,result in pool.map(run,[100,150,200]):
  metadata['runs'][cap]=result
  (OUT/'run-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
  print(cap,json.dumps(result),flush=True)
metadata['finished_at']=stamp();assert all(v['binary_sha256_after']==metadata['binary_sha256'] for v in metadata['runs'].values())
(OUT/'run-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
