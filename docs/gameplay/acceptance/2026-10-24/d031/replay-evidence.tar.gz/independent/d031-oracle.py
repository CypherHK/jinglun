"""D031 independent arithmetic oracle. Uses replay raw metrics, never driver policy decisions."""
import argparse, collections, hashlib, json
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('raw');P.add_argument('--baseline');P.add_argument('--out',required=True);a=P.parse_args()
def read(p):
 return [json.loads(l) for l in open(p) if l.strip()]
rows=read(a.raw); groups=[r for r in rows if r.get('kind')=='bounded_b15'];raw=[r['replay'] for r in rows if r.get('kind')=='script_replay']
assert len(groups)==4
assert not [r for r in rows if r.get('kind')=='script_execution_error']
assert {(g['site'],g['route']) for g in groups}=={(8,1),(8,2),(29,1),(29,2)}
choices=('W','E','Decline');eps=(0,0,1000000,1000000,1000000,1000000)
def vector(o,union=False):
 m=o['metrics'];return (m['attainment_month'] or 25,m['guardrail_union_months'] if union else sum(m['guardrail_months']),-m['treasury_less_unpaid_future_e'],*[-n for n in m['final_three_recurring']])
def relation(a,b,eps):return tuple(0 if abs(x-y)<=e else (-1 if x<y else 1) for x,y,e in zip(a,b,eps))
def weak(a,b,e=eps):return max(relation(a,b,e))<=0
def dom(a,b,e=eps):return weak(a,b,e) and min(relation(a,b,e))<0
def policy(site,route,witnesses,equal):return not equal and all(site==8 and route==2 and w['choice']=='W' for w in witnesses)
# Exercise the narrow exception independently: full ties, E, Decline, and all other groups fail.
for site,route in ((8,1),(8,2),(29,1),(29,2)):
 for choice in choices:
  assert policy(site,route,[{'choice':choice}],False)==(site==8 and route==2 and choice=='W')
 assert not policy(site,route,[],True)
 assert policy(site,route,[],False)
byraw={}
for r in raw:
 assert r['execution_error'] is None and len(r['monthly'])==24 and r['outcome'] is not None
 o=r['outcome'];m=o['metrics'];h=[x['record'] for x in r['monthly']];report=r['report'];assert [x['month'] for x in h]==list(range(1,25))
 assert m['guardrail_months']==[sum(not x[k] for x in h) for k in ('housing_ok','clinic_ok','security_ok')]
 assert m['guardrail_union_months']==sum(not all(x[k] for k in ('housing_ok','clinic_ok','security_ok')) for x in h)
 assert m['final_three_recurring']==[x['recurring_balance'] for x in h[-3:]]
 assert m['treasury_less_unpaid_future_e']==h[-1]['treasury']-report['future_energy_liability']-report['unpaid_energy_arrears']
 good=lambda x: all(x[k] for k in ('scale_met','sustainable','housing_ok','clinic_ok','security_ok'))
 first=next((h[i+2]['month'] for i in range(22) if all(good(x) for x in h[i:i+3])),None)
 achieved=all(good(x) for x in h[-3:])
 assert report['first_sustained_month']==first and (report['grade']=='Achieved')==achieved
 assert m['attainment_month']==(first if achieved else None)
 assert o['id'] not in byraw;byraw[o['id']]=r
if raw: assert len(raw)==444
summary={'source':str(Path(a.raw).resolve()),'source_sha256':hashlib.sha256(Path(a.raw).read_bytes()).hexdigest(),'not_experience_acceptance':True,'b15':[],'b1':[],'raw_scripts':len(raw)}
all_out=[];b15pass=True
for g in groups:
 assert g['scripts']==111 and all(x['fatal']==0 for x in g['counts'].values())
 group_recomputed=[]
 outcomes=g['outcomes'];gs={c:[o for o in outcomes if o['choice']==c] for c in choices};assert all(len(x)==37 for x in gs.values())
 if raw:
  assert all(o==byraw[o['id']]['outcome'] for o in outcomes)
 for union,key in ((False,'sum'),(True,'union')):
  fronts={c:[o for o in os if not any(dom(vector(x,union),vector(o,union),(0,)*6) for x in os)] for c,os in gs.items()}
  witnesses=[o for o in outcomes if all(all(weak(vector(o,union),vector(x,union)) for x in os) and any(dom(vector(o,union),vector(x,union)) for x in os) for c,os in gs.items() if c!=o['choice'])]
  def covers(os,others):return all(any(all(v==0 for v in relation(vector(x,union),vector(y,union),eps)) for y in others) for x in os)
  equal=all(covers(fronts[c],fronts[d]) and covers(fronts[d],fronts[c]) for i,c in enumerate(choices) for d in choices[i+1:])
  expected=g[key];assert equal==expected['all_equivalent'];assert set(o['id'] for o in witnesses)==set(w['script_id'] for w in expected['witnesses']);assert expected['pass']==(not witnesses and not equal)
  for f in expected['frontiers']:assert set(f['script_ids'])=={x['id'] for x in fronts[f['choice']]}
  wp=[{'script_id':o['id'],'choice':o['choice'],'metrics':o['metrics']} for o in witnesses]
  passed=policy(g['site'],g['route'],wp,equal);b15pass &= passed
  group_recomputed.append({'witnesses':[(o['choice'],o['id']) for o in witnesses],'frontiers':{c:[o['id'] for o in f] for c,f in fronts.items()},'all_equivalent':equal,'raw_pass':not witnesses and not equal,'policy_pass':passed})
  summary['b15'].append({'site':g['site'],'route':g['route'],'aggregation':key,'raw_pass':not witnesses and not equal,'all_equivalent':equal,'all_witnesses':wp,'exception_count':len(wp) if passed else 0,'d031_pass':passed,'frontiers':{c:[o['id'] for o in f] for c,f in fronts.items()}})

 assert group_recomputed[0]==group_recomputed[1], 'guardrail sum/union materially differ'
 assert g['raw_pass']==group_recomputed[0]['raw_pass'] and g['policy_pass']==group_recomputed[0]['policy_pass']
 attained={o['id']:o for o in outcomes if o['metrics']['attainment_month'] is not None}
 assert set(attained)=={o['script_id'] for o in g['government_capital_outcomes']}
 if raw:
  raw_group=[r for r in raw if r['script']['site']==g['site'] and r['script']['route']==g['route']]
  assert len(raw_group)==111 and {o['id'] for o in outcomes}=={r['outcome']['id'] for r in raw_group}
  all_out.extend({'script_id':r['outcome']['id'],'choice':r['script']['choice'],'site':g['site'],'route':g['route'],'attainment_month':r['outcome']['metrics']['attainment_month'],'capital':r['government_capital']} for r in raw_group if r['outcome']['metrics']['attainment_month'] is not None)
 else:all_out.extend(g['government_capital_outcomes'])
 for o in g['government_capital_outcomes']:
  if raw:assert o['capital']==byraw[o['script_id']]['government_capital'] and o['attainment_month']==byraw[o['script_id']]['outcome']['metrics']['attainment_month']
b1pass=True
for site in (8,29):
 picked=[]
 for route in (1,2):
  os=[o for o in all_out if o['site']==site and o['route']==route and o['choice']=='Decline' and o['attainment_month']<=24]
  assert os,'four Decline combinations must all remain reachable'
  order=(lambda o:(o['attainment_month'],o['capital']['total']['net_committed'],o['script_id'])) if route==1 else (lambda o:(o['capital']['total']['net_committed'],o['attainment_month'],o['script_id']))
  selected=min(os,key=order);picked.append(selected)
  front=[o for o in os if not any(x['attainment_month']<=o['attainment_month'] and x['capital']['total']['net_committed']<=o['capital']['total']['net_committed'] and (x['attainment_month']<o['attainment_month'] or x['capital']['total']['net_committed']<o['capital']['total']['net_committed']) for x in os)]
  pair=next(p for r in rows if r.get('kind')=='bounded_b1' for p in r['results'] if p['site']==site and p['choice']=='Decline')
  assert selected==pair['selected_route'+str(route)]
  assert {o['script_id'] for o in front}=={o['script_id'] for o in pair['route'+str(route)]['exact_pareto_frontier']}
  summary['b1'].append({'site':site,'route':route,'attained_count':len(os),'selected':selected,'all_frontier_witnesses':front,'frontier_points':sorted(set((o['attainment_month'],o['capital']['total']['net_committed']) for o in front))})
 pair=picked[0]['attainment_month']+2<=picked[1]['attainment_month'] and picked[1]['capital']['total']['net_committed']<picked[0]['capital']['total']['net_committed']
 if site==8:b1pass &= pair
 else:summary['known_gap']={'site':29,'route_difference_pass':pair,'route1':picked[0],'route2':picked[1]}
fastest=min(o['attainment_month'] for o in all_out if o['site']==8 and o['choice']=='Decline')
w={site:[o for o in all_out if o['site']==site and o['choice']=='W'] for site in (8,29)}
summary['eight_fastest']=fastest;summary['eight_w_all_attained_witnesses']=w[8];summary['twenty_nine_w_all_attained_witnesses']=w[29]
b1pass &= fastest<=20 and bool(w[8]) and not w[29]
summary['exception_group_count']=sum(x['exception_count']>0 for x in summary['b15'] if x['aggregation']=='sum')
summary['exception_unique_script_count']=len({w['script_id'] for x in summary['b15'] for w in x['all_witnesses'] if x['d031_pass']})
summary['b1_pass']=b1pass;summary['b15_pass']=b15pass;summary['d031_pass']=b1pass and b15pass
if a.baseline:
 old=[r['replay'] for r in read(a.baseline) if r.get('kind')=='script_replay'];oldmap={r['outcome']['id']:r for r in old};assert len(oldmap)==444 and oldmap.keys()==byraw.keys()
 diffs=[sid for sid,r in byraw.items() if r!=oldmap[sid]];assert not diffs, diffs[:10]
 summary['baseline_comparison']={'baseline':str(Path(a.baseline).resolve()),'strict_full_replay_objects_equal':True,'equal_script_count':444,'equal_month_count':444*24,'excluded_fields':[]}
# Driver fields are compared only after independently deriving every policy result above.
br=next(r for r in rows if r.get('kind')=='bounded_b1');assert br['pass']==b1pass and br['raw_pass']==False
sc=next(r for r in rows if r.get('kind')=='search_domain');assert sc['domestic_demand_capacity']==200 and sc['domestic_demand_trial_cap'] is None and sc['labor_recruitment_experiment']==False and sc['d031_configuration_in_scope']==True
b8=next(r for r in rows if r.get('kind')=='bounded_b8');assert b8['status']=='out_of_scope' and b8['pass'] is None
ar=next(r for r in rows if r.get('kind')=='acceptance_result');assert ar['b1_pass']==b1pass and ar['all_b15_pass']==b15pass and ar['status']=='passed' and ar['exit_code']==0 and ar['raw_pass']==False and ar['policy_pass']==True and ar['all_b15_raw_pass']==False and ar['script_count']==444
Path(a.out).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('b15','b1','eight_w_all_attained_witnesses','known_gap')},ensure_ascii=False,indent=2))
