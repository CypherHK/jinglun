import collections,hashlib,json
from pathlib import Path
ROOT=Path(__file__).parent;OUT=ROOT/'replay'
def lifecycle(f,phase):
 p=f['phase']
 return {'nonclosed':p!='Closed','operating':p in ('Operating','Reduced','ClosureWarned') and not f['water_suspended'],'building':p=='Construction','positive_output':f['output']>0}[phase]
def analyze(cap):
 src=OUT/f'cap-{cap}-444.jsonl';result={'capacity':cap,'financial_scope':'Actual revenue is the sum of named domestic/export receipts. Engine profit and accrued wage/energy/fixed/sales tax are not a cash margin. Named wage/long-energy/sales-tax transfers are per factory; remaining cash receipts stay at group level in raw monthly.system_receipts. Zero revenue gives null margin, with engine loss retained. Closed later months carry null current profit rather than stale state profit.','coexistence_scope':'Every disclosed script and every M1-M24 is scanned. A strict peak requires both capital 39 and the selected candidate to have at least one factory in the same month and phase. Count excludes existing industry.','script_count':0,'execution_errors':[],'groups':[],'strict_capital_candidate_coexistence':[],'factory_finance_checks':{'active_factory_months':0,'zero_revenue_factory_months':0,'clamped_profit_factory_months':0,'violations':[]}}
 peaks={};witnesses={};trace_labor={};raw_audits={}
 for line in src.open():
  row=json.loads(line);kind=row['kind']
  if kind=='script_replay':
   r=row['replay'];result['script_count']+=1;s=r['script'];site=s['site'];rid=r['outcome']['id'] if r['outcome'] else None
   if r['execution_error']:result['execution_errors'].append(r['execution_error'])
   assert r['labor_trial_audit']['monthly'][-1]['national']['cumulative_employed_recruits']==0
   if cap==200:trace_labor[rid]=r['labor_trial_audit']
   for idx,m in enumerate(r['monthly'],1):
    for phase in ['nonclosed','operating','building','positive_output']:
     by_site=collections.defaultdict(list)
     for f in m['factories']:
      if lifecycle(f,phase):by_site[f['site']].append(f['id'])
     key=(site,phase);v=sum(len(by_site[x]) for x in [39,site]) if by_site[39] and by_site[site] else 0
     if v>peaks.get(key,0):peaks[key]=v;witnesses[key]={'script_id':rid,'month':idx,'count':v,'capital_ids':by_site[39],'candidate_ids':by_site[site]}
   stats=result['factory_finance_checks']
   for fid,f in r['trade_audit']['factories'].items():
    for month,a in f['monthly_factory_audit'].items():
     assert a['actual_revenue']==sum(f['monthly'][month][k] for k in ['domestic_receipt_income','export_receipt_income'])
     if a['engine_costs_apply_this_month']:
      stats['active_factory_months']+=1
      if a['actual_revenue']==0:
       stats['zero_revenue_factory_months']+=1
       assert a['engine_profit_over_actual_revenue'] is None
      expected=a['actual_revenue']-sum(a['engine_accrued_costs'].values());actual=a['engine_after_tax_profit_this_month']
      if actual!=expected:
       if actual==min(expected,-1):stats['clamped_profit_factory_months']+=1
       else:stats['violations'].append({'script_id':rid,'factory':fid,'month':month,'expected':expected,'actual':actual})
     else:assert a['engine_after_tax_profit_this_month'] is None
  elif kind=='bounded_b15':
   records=row['government_capital_records'];national=[r['trade_audit']['export_sales_actual_payment'] for r in records];candidate=[r['trade_audit']['sites'].get(str(row['site']),{}).get('export_receipt_income',0) for r in records]
   result['groups'].append({'site':row['site'],'route':row['route'],'scripts':row['scripts'],'counts':row['counts'],'sum':row['sum'],'union':row['union'],'national_new_factory_export_range':[min(national),max(national)],'national_new_factory_export_positive_count':sum(v>0 for v in national),'candidate_new_factory_export_range':[min(candidate),max(candidate)],'candidate_new_factory_export_positive_count':sum(v>0 for v in candidate),'export_positive_scripts':row['export_positive_scripts']})
  elif kind=='bounded_b1':result['b1']=row
  elif kind=='acceptance_result':result['acceptance']=row
 for site in [8,29]:
  for phase in ['nonclosed','operating','building','positive_output']:
   result['strict_capital_candidate_coexistence'].append({'site':site,'phase':phase,'peak':peaks.get((site,phase),0),'witness':witnesses.get((site,phase))})
 assert result['script_count']==444 and not result['execution_errors'] and not result['factory_finance_checks']['violations']
 (OUT/f'cap-{cap}-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(cap,'B1',result['b1']['pass'],'B15',[(g['site'],g['route'],g['sum']['pass']) for g in result['groups']],'exports',[(g['site'],g['route'],g['national_new_factory_export_range'],g['national_new_factory_export_positive_count']) for g in result['groups']],flush=True)
 if cap==200:
  old=[json.loads(l) for l in (ROOT/'previous/replay/off-444.jsonl').open()];now=[json.loads(l)for l in (OUT/f'cap-{cap}-compact.jsonl').open()]
  def clean(v):
   if isinstance(v,dict):return {k:clean(x)for k,x in v.items()if k not in ['monthly_factory_audit','labor_trial_audit','domestic_demand_capacity','domestic_demand_trial_cap']}
   if isinstance(v,list):return [clean(x)for x in v]
   return v
  checks={kind:[clean(x)for x in now if x['kind']==kind]==[clean(x)for x in old if x['kind']==kind] for kind in ['search_domain','bounded_b15','bounded_b1','bounded_trade_audit','acceptance_result']}
  labor=0
  for group in [r for r in old if r['kind']=='bounded_b15']:
   for rec in group['government_capital_records']:
    rid=rec['script_id'];a,b=trace_labor[rid],rec['labor_trial_audit'];assert a['monthly']==b['monthly'],rid;assert a['scope']==b['scope'];labor+=1
  checks['legacy_labor_monthly_exact_scripts']=labor;checks['all_equal']=all(v is True for k,v in checks.items()if k!='legacy_labor_monthly_exact_scripts') and labor==444
  checks['excluded_fields']=['new factory monthly_factory_audit','new domain capacity/cap','compact labor_trial_audit; all legacy labor monthly/scope compared separately against raw; strict peak semantics independently rechecked']
  assert checks['all_equal'],checks
  (OUT/'cap-200-previous-off-comparison.json').write_text(json.dumps(checks,indent=2)+'\n')
for cap in [100,150,200]:analyze(cap)
