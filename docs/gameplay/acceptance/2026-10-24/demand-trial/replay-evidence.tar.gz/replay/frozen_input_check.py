import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd();p='crates/gameplay/data/jinglun-040-initial-draft.json'
current=json.loads((ROOT/p).read_text());baseline=json.loads(subprocess.check_output(['git','show','ab17d08:'+p]));approved=json.loads(subprocess.check_output(['git','show','3f8bfb423d6d686da03c25b7fcab706e3ddd6af9:'+p]))
def nums(x,p=''):
 if isinstance(x,dict):return {k:v for a,b in x.items() for k,v in nums(b,p+'/'+a).items()}
 if isinstance(x,list):return {k:v for a,b in enumerate(x) for k,v in nums(b,p+'/'+str(a)).items()}
 return {p:(type(x).__name__,x)} if isinstance(x,(int,float)) and not isinstance(x,bool) else {}
a,b=nums(current),nums(approved);assert a==b
checks={'approved_numeric_paths':len(a),'numeric_values_and_types_equal_approved':a==b,'provenance_equal_baseline':current['provenance']==baseline['provenance'],'approval_equal_baseline':current['approval']==baseline['approval'],'all_document_fields_except_current_design_inputs_equal_baseline':{k:v for k,v in current.items()if k!='current_design_inputs'}=={k:v for k,v in baseline.items()if k!='current_design_inputs'},'current_design_inputs':current['current_design_inputs']}
assert all(checks[k] for k in ['numeric_values_and_types_equal_approved','provenance_equal_baseline','approval_equal_baseline','all_document_fields_except_current_design_inputs_equal_baseline'])
for name,sha in current['current_design_inputs']['source_hashes'].items():assert hashlib.sha256((Path('/Users/wangyucheng/Projects/jinglun-design/design')/name).read_bytes()).hexdigest()==sha
(ROOT/'target/demand-trial/replay/frozen-input-check.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
