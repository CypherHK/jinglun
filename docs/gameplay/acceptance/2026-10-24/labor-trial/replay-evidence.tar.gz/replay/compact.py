import json,sys
from pathlib import Path
root=Path(__file__).parent
for state in ['off','on']:
 path=root/f'{state}-444.jsonl'
 if not path.exists():continue
 rows=[json.loads(l) for l in path.open()]
 if not any(x['kind']=='bounded_b1' for x in rows):continue
 result={'state':state,'b1':next(x for x in rows if x['kind']=='bounded_b1'),'acceptance':rows[-1],'groups':[]}
 all_records=[]
 for g in [x for x in rows if x['kind']=='bounded_b15']:
  records=g['government_capital_records'];all_records+=records
  incomes=[r['trade_audit']['export_sales_actual_payment'] for r in records]
  candidate_incomes=[r['trade_audit']['sites'].get(str(g['site']),{}).get('export_receipt_income',0) for r in records]
  loss_fields=['cumulative_outbound','cumulative_idle_recruits','cumulative_employed_recruits','lost_worker_months','cumulative_wage_loss','cumulative_payroll_tax_loss']
  losses={field:[min(r['labor_trial_audit']['monthly'][-1]['national'][field] for r in records),max(r['labor_trial_audit']['monthly'][-1]['national'][field] for r in records)] for field in loss_fields}
  max_loss=max(records,key=lambda r:r['labor_trial_audit']['monthly'][-1]['national']['cumulative_wage_loss'])
  result['groups'].append({'site':g['site'],'route':g['route'],'scripts':g['scripts'],'counts':g['counts'],'sum':g['sum'],'union':g['union'],'national_new_factory_export_range':[min(incomes),max(incomes)],'national_export_positive_count':sum(v>0 for v in incomes),'candidate_export_range':[min(candidate_incomes),max(candidate_incomes)],'candidate_export_positive_count':sum(v>0 for v in candidate_incomes),'positive_scripts':g['export_positive_scripts'],'national_source_totals_range_across_alternative_scripts':losses,'max_wage_loss_script':max_loss['script_id'],'max_wage_loss_national':max_loss['labor_trial_audit']['monthly'][-1]['national'],'max_wage_loss_sources':max_loss['labor_trial_audit']['monthly'][-1]['sources']})

 result['strict_capital_candidate_coexistence']=[]
 for site in [8,29]:
  records=[r for r in all_records if r['script_id'].startswith(f's{site}-')]
  for phase in ['nonclosed','operating','building']:
   key='capital_candidate_simultaneous/'+phase
   upper=max(r['labor_trial_audit']['simultaneous_factory_peaks'][key]['count'] for r in records)
   matches=[]
   for r in records:
    v=r['labor_trial_audit']['simultaneous_factory_peaks'][key]
    if v['count']==upper and v['factory_ids_by_site'].get('39') and v['factory_ids_by_site'].get(str(site)):
     matches.append({'script_id':r['script_id'],**v})
   result['strict_capital_candidate_coexistence'].append({'site':site,'phase':phase,'upper_bound':upper,'maximum_proven':bool(matches),'witnesses':matches[:3]})
 result['source_counter_scope']='On: actual all-source cumulative migration and displacement. Off: trial migration counters are inactive; zero outbound/idle counters do not mean no idle migration. Off employed displacement and wage loss are zero by disabled experimental policy.'
 result['script_count']=len(all_records)
 result['trade']=next(x for x in rows if x['kind']=='bounded_trade_audit')
 witnesses=set()
 def find(v):
  if isinstance(v,dict):
   for k,x in v.items():
    if k in ['script_id','id'] and isinstance(x,str) and x.startswith('s'):witnesses.add(x)
    find(x)
  elif isinstance(v,list):
   for x in v:find(x)
 find(result['b1']); find(result['trade']['selected_decline_scripts'])
 result['witness_labor']={r['script_id']:r['labor_trial_audit'] for r in all_records if r['script_id'] in witnesses}
 result['all_script_labor_terminal']={r['script_id']:{'national':r['labor_trial_audit']['monthly'][-1]['national'],'sources':r['labor_trial_audit']['monthly'][-1]['sources'],'simultaneous_factory_peaks':r['labor_trial_audit']['simultaneous_factory_peaks']} for r in all_records}
 (root/f'{state}-compact.json').write_text(json.dumps(result,indent=2)+'\n')
 print(state,'scripts',len(all_records),'B1',result['b1']['pass'],'acceptance',result['acceptance']['status'])
 print('exports',[(g['site'],g['route'],g['national_new_factory_export_range'],g['national_export_positive_count'])for g in result['groups']])
 print('max_employed',max(r['labor_trial_audit']['monthly'][-1]['national']['cumulative_employed_recruits']for r in all_records))
 if state=='off':
  baseline=[json.loads(l)for l in (root/'d028-replay/d028-final-444.jsonl').open()]
  def clean(v):
   if isinstance(v,dict):return {k:clean(x)for k,x in v.items()if k not in ['labor_trial_audit','labor_recruitment_experiment','experiment_status']}
   if isinstance(v,list):return [clean(x)for x in v]
   return v
  checks={}
  for kind in ['bounded_b15','bounded_b1','bounded_trade_audit','acceptance_result']:
   checks[kind]=[clean(x)for x in rows if x['kind']==kind]==[clean(x)for x in baseline if x['kind']==kind]
  (root/'off-baseline-comparison.json').write_text(json.dumps(checks,indent=2)+'\n');print('baseline',checks)
